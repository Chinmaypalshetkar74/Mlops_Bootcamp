from datetime import datetime
import os

from Networksecurity.Constants import Training_pipeline


class trainingPiplineConfig:

    def __init__(self, timestamp=None):

        if timestamp is None:
            timestamp = datetime.now()

        timestamp = timestamp.strftime("%m-%d-%Y-%H-%M-%S")

        self.pipeline_name = Training_pipeline.Pipeline_Name

        self.artifact_name = Training_pipeline.Artifact_Dir

        self.artifact_dir = os.path.join(
            self.artifact_name,
            timestamp
        )

        self.timestamp = timestamp


class DataIngestionConfig:

    def __init__(
        self,
        training_pipline_config: trainingPiplineConfig
    ):

        self.data_ingestion_dir = os.path.join(
            training_pipline_config.artifact_dir,
            Training_pipeline.Data_Ingestion_DIR_Name
        )

        self.feature_store_file_path = os.path.join(
            self.data_ingestion_dir,
            Training_pipeline.Data_Ingestion_Feature_Store_DIR_Name,
            Training_pipeline.File_Name
        )

        self.training_file_path = os.path.join(
            self.data_ingestion_dir,
            Training_pipeline.Data_Ingestion_Ingested_Name,
            Training_pipeline.Train_file_name
        )

        self.test_file_path = os.path.join(
            self.data_ingestion_dir,
            Training_pipeline.Data_Ingestion_Ingested_Name,
            Training_pipeline.Test_file_name
        )

        self.train_test_split_ratio = (
            Training_pipeline.Data_Ingestion_Train_Test_Split_Ratio
        )

        self.collection_name = (
            Training_pipeline.Data_Ingestion_Collection_Name
        )

        self.database_name = (
            Training_pipeline.Data_Ingestion_Database_Name
        )


class DataValidationConfig:

    def __init__(
        self,
        training_pipline_config: trainingPiplineConfig
    ):

        self.data_validation_dir = os.path.join(
            training_pipline_config.artifact_dir,
            Training_pipeline.Data_Validation_DIR_Name
        )

        self.valid_data_dir = os.path.join(
            self.data_validation_dir,
            Training_pipeline.Data_Validation_Valid_Dir
        )

        self.invalid_data_dir = os.path.join(
            self.data_validation_dir,
            Training_pipeline.Data_Validation_InValid_Dir
        )

        self.valid_train_file_path = os.path.join(
            self.valid_data_dir,
            Training_pipeline.Train_file_name
        )

        self.valid_test_file_path = os.path.join(
            self.valid_data_dir,
            Training_pipeline.Test_file_name
        )

        self.invalid_train_file_path = os.path.join(
            self.invalid_data_dir,
            Training_pipeline.Train_file_name
        )

        self.invalid_test_file_path = os.path.join(
            self.invalid_data_dir,
            Training_pipeline.Test_file_name
        )

        self.drift_report_file_path = os.path.join(
            self.data_validation_dir,
            Training_pipeline.Data_Validation_Drift_Report_Dir,
            Training_pipeline.Data_Validation_Drift_Report_File_Name
        )

class DataTransformationConfig:

    def __init__(
        self,
        training_pipline_config: trainingPiplineConfig
    ):

        self.data_transformation_dir: str = os.path.join(
            training_pipline_config.artifact_dir,
            Training_pipeline.Data_Transformation_Dir_Name
        )

        self.transformed_data_dir: str = os.path.join(
            self.data_transformation_dir,
            Training_pipeline.Data_Transformation_Transformed_Data_Dir
        )

        self.transformed_train_file_path: str = os.path.join(
            self.transformed_data_dir,
            Training_pipeline.Train_file_name.replace(
                ".csv",
                ".npy"
            )
        )

        self.transformed_test_file_path: str = os.path.join(
            self.transformed_data_dir,
            Training_pipeline.Test_file_name.replace(
                ".csv",
                ".npy"
            )
        )

        self.transformed_object_file_path: str = os.path.join(
            self.data_transformation_dir,
            Training_pipeline.Preprocessing_Object_File_Name
        )

class ModelTrainerConfig:

    def __init__(
        self,
        training_pipline_config: trainingPiplineConfig
    ):

        self.model_trainer_dir = os.path.join(
            training_pipline_config.artifact_dir,
            Training_pipeline.Model_Trainer_DIR_Name
        )

        self.trained_model_file_path = os.path.join(
            self.model_trainer_dir,
            Training_pipeline.Model_Trainer_Trained_Model_Dir,
            Training_pipeline.Model_Trainer_Trained_Model_Name
        )

        self.expected_accuracy_score = (
            Training_pipeline.Model_Trainer_Expected_Score
        )

        self.overfitting_underfitting_threshold = (
            Training_pipeline
            .Model_Trainer_Overfitting_Underfitting_Threshold
        )